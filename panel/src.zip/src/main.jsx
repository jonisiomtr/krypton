import React from 'react'

import ReactDOM from 'react-dom/client'

import {
  BrowserRouter,
  Routes,
  Route
} from 'react-router-dom'

import './App.css'

import Login from './pages/Login'

import Dashboard from './pages/Dashboard'

import Company from './pages/Company'

import PrivateRoute from './components/PrivateRoute'

import CompanyPanel from './pages/CompanyPanel'

ReactDOM.createRoot(
  document.getElementById('root')
).render(

  <BrowserRouter>

    <Routes>

      <Route
        path='/'
        element={<Login />}
      />

      <Route
        path='/dashboard'
        element={

          <PrivateRoute>

            <Dashboard />

          </PrivateRoute>

        }
      />

      <Route
  path='/company-panel'
  element={
    <PrivateRoute>
      <CompanyPanel />
    </PrivateRoute>
  }
/>

      <Route
        path='/company/:id'
        element={

          <PrivateRoute>

            <Company />

          </PrivateRoute>

        }
      />

    </Routes>

  </BrowserRouter>

)