import { useEffect, useState } from 'react'
import api from '../../services/api'

import '../../styles/company-modulos.css'

export default function Modules({ companyId }) {

  
  //console.log(modulosOn)

  const [modules, setModules] =
  useState([])

  useEffect(() => {

    loadModules()

  }, [])

  //funcao loadmodules certa

  async function loadModules() {

  try {

    const token =
    localStorage.getItem('token')

    const response =
    await api.get( `/companies/modules/${companyId}`,{
    headers: {Authorization:`Bearer ${token}`
  }})

  //console.log(response.data.modules)



  setModules( response.data.modules || [] )
  } catch (err) {

    console.log(err)

  }

}
  

  const allModules = [

  {
    key: 'assistant',
    name: 'Assistente IA',
    icon: '🤖',
    description:
    'Responde clientes automaticamente.'
  },

  {
    key: 'catalog',
    name: 'Catálogo',
    icon: '🛍️',
    description:
    'Mostra produtos automaticamente.'
  },

  {
    key: 'delivery',
    name: 'Delivery',
    icon: '🚚',
    description:
    'Sistema automático de entregas.'
  },

  {
    key: 'scheduling',
    name: 'Agendamentos',
    icon: '📅',
    description:
    'Sistema de reservas automático.'
  },

  {
    key: 'pix',
    name: 'PIX Automático',
    icon: '💳',
    description:
    'Cobranças automáticas via pix.'
  }

]

  return (

    <div className='modules-page'>

      <div className='modules-header'>

        <h1>
          Módulos do Sistema
        </h1>

        <p>
          Gerencie os módulos
          da sua empresa
        </p>

      </div>

      <div className='modules-grid'>

        {

          allModules.map((module, index) => {

            const active =
            modules.includes(
              module.key
            )

            return (

              <div

                key={index}

                className={

                  `module-card ${
                    active
                    ? 'active'
                    : 'locked'
                  }`

                }

              >

                {

                  !active && (

                    <div className='module-lock'>

                      🔒

                    </div>

                  )

                }

                <div className='module-top'>

                  <div className='module-icon'>
                    {module.icon}
                  </div>

                  <div
                    className={`module-status ${
                      active
                      ? 'on'
                      : 'off'
                    }`}
                  >

                    {

                      active
                      ? 'ATIVO'
                      : 'BLOQUEADO'

                    }

                  </div>

                </div>

                <h2>
                  {module.name}
                </h2>

                <p>
                  {module.description}
                </p>

                {

  active ? (

    <button
      className='module-button-on'
    >

      ✅ Liberado

    </button>

  ) : (

    <button
      className='module-button-off'
    >

      💎 Comprar Módulo

    </button>

  )

}

              </div>

            )

          })

        }

      </div>

    </div>

  )

}