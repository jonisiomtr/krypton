import { useEffect, useState } from 'react'

export default function Products() {
  const [products, setProducts] = useState([])
  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  const token = localStorage.getItem('token')

  async function loadProducts() {
    const res = await fetch('http://localhost:3000/api/products', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })

    const data = await res.json()
    setProducts(data)
  }

  async function addProduct() {
    
  const res = await fetch('http://localhost:3000/api/products', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ name, price })
    
  })


  const data = await res.json()

  if (!res.ok) {
    alert(data.error)
    return
  }

  setProducts(data)
  setName('')
  setPrice('')
}

async function removeProduct(name) {

  const res = await fetch(
    `http://localhost:3000/api/products/${name}`,
    {
      method: 'DELETE',

      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  )

  const data = await res.json()

  setProducts(data)

}

  useEffect(() => {
    loadProducts()
  }, [])

  return (

  <div className='services-page'>

    <div className='services-header'>

      <div>
        <h2>📦 Produtoses</h2>

        <p>
          Gerencie os produtos da sua empresa
        </p>
      </div>

    </div>

    <div className='service-form-card'>

      <input
        placeholder='Nome do produto'
        value={name}
        onChange={e => setName(e.target.value)}
      />

      <input
        placeholder='Preço'
        value={price}
        onChange={e => setPrice(e.target.value)}
      />

      <button onClick={addProduct}>
        + Adicionar Produto
      </button>

    </div>

    <div className='services-grid'>

      {

        products.map((product, index) => (

          <div
            className='service-card'
            key={index}
          >

            <div className='service-top'>

  <div className='service-icon'>
    📦
  </div>

  <button
    className='remove-btn'
    onClick={() =>
      removeProduct(product.name)
    }
  >
    ✕
  </button>

</div>

            <h3>
              {product.name}
            </h3>

            <p>
              R$ {product.price}
            </p>

          </div>

        ))

      }

    </div>

  </div>

)
}