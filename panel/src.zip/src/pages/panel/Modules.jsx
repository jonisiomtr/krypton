export default function Modules() {
  return (
    <div>
      <h2>🧠 Módulos Ativos</h2>
      <p>Quais módulos a empresa possui</p>
    </div>
  )
}