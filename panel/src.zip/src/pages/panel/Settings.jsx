import { useState } from 'react'
import api from '../../services/api'

import '../../styles/company-panel.css'

export default function Settings() {

  // MODAIS
  const [showProfile, setShowProfile] =
  useState(false)

  const [showPassword, setShowPassword] =
  useState(false)

  // SENHA
  const [newPassword, setNewPassword] =
  useState('')

  const [confirmPassword, setConfirmPassword] =
  useState('')

  const companyId =
  localStorage.getItem(
    'companyId'
  )

  const [displayName, setDisplayName] =
  useState(

    localStorage.getItem(
      'companyDisplayName'
    ) || ''

  )

  const [logo, setLogo] =
  useState(null)

  const [preview, setPreview] =
  useState(

    localStorage.getItem(
      'companyLogo'
    ) ||

    'https://placehold.co/150'

  )

  const [loading, setLoading] =
  useState(false)

  // =========================
  // SALVAR CONFIG
  // =========================
  async function saveSettings() {

    try {

      setLoading(true)

      const formData =
      new FormData()

      formData.append(
        'companyId',
        companyId
      )

      formData.append(
        'displayName',
        displayName
      )

      if (logo) {

        formData.append(
          'logo',
          logo
        )

      }

      const response =
      await api.post(

        '/company/settings',

        formData,

        {

          headers: {

            'Content-Type':
            'multipart/form-data'

          }

        }

      )

      localStorage.setItem(

        'companyDisplayName',

        displayName

      )

      if (
        response.data.config.logo
      ) {

        const logoUrl =
        `http://localhost:3000${response.data.config.logo}`

        localStorage.setItem(
          'companyLogo',
          logoUrl
        )

      }

      alert(
        'Configurações salvas!'
      )

      window.location.reload()

    } catch (err) {

      console.log(err)

      alert(
        'Erro ao salvar'
      )

    } finally {

      setLoading(false)

    }

  }

  // =========================
  // ALTERAR SENHA
  // =========================
  async function changePassword() {

    if (
      !newPassword ||
      !confirmPassword
    ) {

      return alert(
        'Preencha todos os campos'
      )

    }

    if (
      newPassword !==
      confirmPassword
    ) {

      return alert(
        'As senhas não coincidem'
      )

    }

    try {

      await api.post(

        '/company/password',

        {

          companyId,

          password:
          newPassword

        }

      )

      alert(
        'Senha alterada com sucesso!'
      )

      setNewPassword('')
      setConfirmPassword('')

      setShowPassword(false)

    } catch (err) {

      console.log(err)

      alert(
        'Erro ao alterar senha'
      )

    }

  }

  // =========================
  // PREVIEW LOGO
  // =========================
  function handleLogo(e) {

    const file =
    e.target.files[0]

    if (!file) return

    setLogo(file)

    setPreview(
      URL.createObjectURL(file)
    )

  }

  return (

    <div className='settings-page'>

      {/* BOTÕES */}
      <div className='settings-actions'>

        <button

          className='open-button'

          onClick={() => {

            setShowProfile(true)
            setShowPassword(false)

          }}

        >

          Editar Perfil

        </button>

        <button

          className='open-button password'

          onClick={() => {

            setShowPassword(true)
            setShowProfile(false)

          }}

        >

          Alterar Senha

        </button>

      </div>

      {/* PERFIL */}
      {

        showProfile && (

          <div className='settings-card'>

            <button

              className='close-button'

              onClick={() =>

                setShowProfile(false)

              }

            >

              ✕

            </button>

            <h2>
              Configurações
            </h2>

            <div className='logo-preview'>

              <img

                src={preview}

                alt='logo'

                className='settings-logo'

              />

            </div>

            <label
              className='upload-button'
            >

              Alterar Logo

              <input

                type='file'

                accept='image/*'

                onChange={handleLogo}

                hidden

              />

            </label>

            <div className='input-group'>

              <label>
                Nome da Empresa
              </label>

              <input

                type='text'

                placeholder='Digite o nome'

                value={displayName}

                onChange={(e) =>

                  setDisplayName(
                    e.target.value
                  )

                }

              />

            </div>

            <button

              className='save-button'

              onClick={saveSettings}

              disabled={loading}

            >

              {

                loading

                ? 'Salvando...'

                : 'Salvar Configurações'

              }

            </button>

          </div>

        )

      }

      {/* SENHA */}
      {

        showPassword && (

          <div className='settings-card'>

            <button

              className='close-button'

              onClick={() =>

                setShowPassword(false)

              }

            >

              ✕

            </button>

            <h2>
              Alterar Senha
            </h2>

            <div className='input-group'>

              <label>
                Nova senha
              </label>

              <input

                type='password'

                value={newPassword}

                onChange={(e) =>

                  setNewPassword(
                    e.target.value
                  )

                }

              />

            </div>

            <div className='input-group'>

              <label>
                Confirmar senha
              </label>

              <input

                type='password'

                value={confirmPassword}

                onChange={(e) =>

                  setConfirmPassword(
                    e.target.value
                  )

                }

              />

            </div>

            <button

              className='save-button'

              onClick={changePassword}

            >

              Salvar Nova Senha

            </button>

          </div>

        )

      }

    </div>

  )

}