import { useEffect, useState } from 'react'

export default function Services() {

  const [services, setServices] = useState([])

  const [name, setName] = useState('')
  const [price, setPrice] = useState('')

  const token = localStorage.getItem('token')

  async function loadServices() {

    const res = await fetch(
      'http://localhost:3000/api/services',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    )

    const data = await res.json()

    setServices(data)
  }

  async function addService() {

    const res = await fetch(
      'http://localhost:3000/api/services',
      {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },

        body: JSON.stringify({
          name,
          price
        })
      }
    )

    const data = await res.json()

    if (!res.ok) {
      alert(data.error)
      return
    }

    setServices(data)

    setName('')
    setPrice('')
  }

  async function removeService(id) {

    const res = await fetch(
      `http://localhost:3000/api/services/${id}`,
      {
        method: 'DELETE',

        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    )

    const data = await res.json()

    setServices(data)
  }

  useEffect(() => {
    loadServices()
  }, [])

  return (

  <div className='services-page'>

    <div className='services-header'>

      <div>
        <h2>🧰 Serviços</h2>
        <p>
          Gerencie os serviços do seu negócio
        </p>
      </div>

    </div>

    <div className='service-form-card'>

      <input
        placeholder='Nome do serviço'
        value={name}
        onChange={e => setName(e.target.value)}
      />

      <input
        placeholder='Preço'
        value={price}
        onChange={e => setPrice(e.target.value)}
      />

      <button onClick={addService}>
        + Adicionar Serviço
      </button>

    </div>

    <div className='services-grid'>

      {

        services.map(service => (

          <div
            className='service-card'
            key={service.id}
          >

            <div className='service-top'>

              <div className='service-icon'>
                ✂️
              </div>

              <button
                className='remove-btn'
                onClick={() =>
                  removeService(service.id)
                }
              >
                ✕
              </button>

            </div>

            <h3>
              {service.name}
            </h3>

            <p>
              R$ {service.price}
            </p>

          </div>

        ))

      }

    </div>

  </div>

)

}