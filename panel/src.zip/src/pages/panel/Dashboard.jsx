export default function Dashboard() {
  return (
    <div>
      <h2>📊 Visão Geral</h2>
      <p>Resumo da empresa</p>
    </div>
  )
}