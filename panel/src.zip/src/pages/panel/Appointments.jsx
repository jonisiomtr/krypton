import { useEffect, useState } from 'react'

export default function Appointments() {

  const [appointments, setAppointments] = useState([])

  const token = localStorage.getItem('token')

  async function loadAppointments() {

    try {

      const res = await fetch(
        'http://localhost:3000/api/appointments',
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      const data = await res.json()

      setAppointments(data)

    } catch (err) {

      console.log(err)

    }

  }

  useEffect(() => {

    loadAppointments()

  }, [])

  return (

    <div className='services-page'>

      <div className='services-header'>

        <div>
          <h2>📅 Agendamentossss</h2>

          <p>
            Clientes agendadoss
          </p>
        </div>

      </div>

      <div className='services-grid'>

        {

          appointments.map(appointment => (

            <div
              className='service-card'
              key={appointment.id}
            >

              <div className='service-top'>

                <div className='service-icon'>
                  📅
                </div>

              </div>

              <h3>
                {appointment.service.name}
              </h3>

              <p>
                ⏰ {appointment.time}
              </p>

              <p>
                👤 {appointment.customer}
              </p>

            </div>

          ))

        }

      </div>

    </div>

  )

}