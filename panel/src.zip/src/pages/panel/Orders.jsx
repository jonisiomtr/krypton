import { useEffect, useState } from 'react'
import api from '../../services/api'

import '../../styles/company-orders.css'

export default function Orders({ companyId }) {

  const [orders, setOrders] =
  useState([])

  useEffect(() => {

    if (companyId) {

      loadOrders()

    }

  }, [companyId])

  async function updateOrderStatus(
    index,
    status
  ) {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      await api.put(

        `/pedidos/companies/orders/${companyId}/${index}`,

        {
          status
        },

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      loadOrders()

    } catch (err) {

      console.log(err)

    }

  }

  async function loadOrders() {

    try {

      const token =
      localStorage.getItem('token')

      const response =
      await api.get(

        `/pedidos/listar/orders/${companyId}`,

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      setOrders(
        response.data.orders || []
      )

    } catch (err) {

      console.log(err)

    }

  }

  return (

    <div className='orders-page'>

      <div className='orders-header'>

        <div>

          <h1>
            Pedidos
          </h1>

          <p>
            {orders.length} pedidos recebidos pelo bot
          </p>

        </div>

        <div className='orders-badge'>

          {orders.length} pedidos

        </div>

      </div>

      {

        orders.length === 0 && (

          <div className='orders-empty'>

            <div className='orders-empty-icon'>
              📦
            </div>

            <h2>
              Nenhum pedido encontrado
            </h2>

            <p>
              Os pedidos feitos no WhatsApp
              aparecerão aqui.
            </p>

          </div>

        )

      }

      <div className='orders-grid'>

        {

          orders.map((order, index) => {

            let total = 0

            order.cart?.forEach(product => {

              total += Number(product.price)

            })

            return (

              <div
                key={index}
                className= {`order-card ${order.status}`}
              >

                <div className='order-glow'></div>

                <div className='order-top'>

                  <div className='order-user'>

                    <div className='order-avatar'>
                      👤
                    </div>

                    <div>

                      <h3>
                        Cliente
                      </h3>

                      <span>
                        {order.number}
                      </span>

                    </div>

                  </div>

                  <div
                    className={`order-status ${
                      order.status
                    }`}
                  >

                    {
                      order.status === 'pending' &&
                      '🟠 PENDENTE'
                    }

                    {
                      order.status === 'accepted' &&
                      '🟢 ACEITO'
                    }

                    {
                      order.status === 'finished' &&
                      '⚫ FINALIZADO'
                    }

                  </div>

                </div>

                <div className='order-products'>

                  {

                    order.cart?.map((product, i) => (

                      <div
                        key={i}
                        className='order-product'
                      >

                        <span>
                          🛒 {product.name}
                        </span>

                        <strong>
                          R$ {product.price}
                        </strong>

                      </div>

                    ))

                  }

                </div>

                <div className='order-footer'>

                  <div className='order-address'>

                    📍 {order.address}

                  </div>

                  <div className='order-payment'>

                    💳 {order.payment}

                  </div>

                </div>

                <div className='order-total'>

                  Total:

                  <strong>
                    R$ {total}
                  </strong>

                </div>

                <div className='order-actions'>

                  {

                    order.status === 'pending' && (

                      <button

                        className='accept-order'

                        onClick={() =>

                          updateOrderStatus(
                            index,
                            'accepted'
                          )

                        }

                      >

                        ✅ Aceitar

                      </button>

                    )

                  }

                  {

                    order.status === 'accepted' && (

                      <button

                        className='finish-order'

                        onClick={() =>

                          updateOrderStatus(
                            index,
                            'finished'
                          )

                        }

                      >

                        🚚 Finalizar

                      </button>

                    )

                  }

                  {

                    order.status === 'finished' && (

                      <button
                        className='finished-order'
                        disabled
                      >

                        ✅ Pedido Finalizado

                      </button>

                    )

                  }

                </div>

              </div>

            )

          })

        }

      </div>

    </div>

  )

}