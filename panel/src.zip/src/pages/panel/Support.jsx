import '../../styles/suporte.css'



export default function Support() {

  return (

    <div className='support-page'>

      <div className='support-header'>

  <div className='support-badge'>
    🚀 SUPORTE PREMIUM
  </div>

  <h2>
    Central de Suporte
  </h2>

  <p>
    Atendimento direto com o desenvolvedor do sistema.
    Suporte rápido, atualizações e ajuda personalizada.
  </p>

</div>

      <div className='support-cards'>

        <a

          href='https://instagram.com/johnzinnasteclas'

          target='_blank'

          rel='noreferrer'

          className='support-card instagram'

        >

          <div className='support-icon'>
            📸
          </div>

          <div>

            <h3>
              Instagram
            </h3>

            <p>
              @johnzinnasteclas
            </p>

          </div>

        </a>

        <a

          href='https://wa.me/5591991873356'

          target='_blank'

          rel='noreferrer'

          className='support-card whatsapp'

        >

          <div className='support-icon'>
            💬
          </div>

          <div>

            <h3>
              WhatsApp
            </h3>

            <p>
              (91) 99187-3356
            </p>

          </div>

        </a>

      </div>




    <div className='support-tags'>

  <div className='support-tag'>
    💎 Cliente VIP
  </div>

  <div className='support-tag'>
    🔥 Sistema 100% Online
  </div>

  <div className='support-tag'>
    📈 Marketing Digital
  </div>

  <div className='support-tag'>
    🤝 Barbearia Elite
  </div>

  <div className='support-tag'>
    ⚡ Painel by John
  </div>

  <div className='support-tag'>
    🚀 Automação Premium
  </div>

</div>









    </div>

  )

}