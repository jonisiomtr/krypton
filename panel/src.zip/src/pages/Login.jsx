import {
  useState
} from 'react'

import {
  useNavigate
} from 'react-router-dom'

import api from '../services/api'

import '../App.css'

export default function Login() {

  const navigate =
  useNavigate()

  const [username,
  setUsername] =
  useState('')

  const [password,
  setPassword] =
  useState('')

  async function login() {
  try {
    const response = await api.post('/auth/login', {
      username,
      password
    })

    localStorage.setItem('token', response.data.token)

    // decodifica o token
    const payload = JSON.parse(atob(response.data.token.split('.')[1]))

    if (payload.type === 'admin') {
      navigate('/dashboard')
    } else {
      //navigate(`/company/${payload.companyId}`) aqui
      localStorage.setItem('companyId', payload.companyId)
      navigate('/company-panel')
    }

  } catch {
    alert('Login inválido')
  }
}

  return (

    <div className='container'>

      <div className='bg1'></div>

      <div className='bg2'></div>

      <div className='login-card'>

        <div className='logo'>
          YP
        </div>

        <h1 className='title'>
          YHWH Painel
        </h1>

        <p className='subtitle'>
          Plataforma inteligente 🚀
        </p>

        <div className='input-group'>

          <label>
            Usuário
          </label>

          <input
            type='text'
            value={username}
            onChange={
              e =>
              setUsername(
                e.target.value
              )
            }
          />

        </div>

        <div className='input-group'>

          <label>
            Senha
          </label>

          <input
            type='password'
            value={password}
            onChange={
              e =>
              setPassword(
                e.target.value
              )
            }
          />

        </div>

        <button
          className='login-button'
          onClick={login}
        >

          Entrar

        </button>

      </div>

    </div>

  )

}