import {
  useNavigate
} from 'react-router-dom'

import {
  useEffect,
  useState
} from 'react'

import api from '../services/api'

import '../App.css'

export default function Dashboard() {

  const [companies,
  setCompanies] =
  useState([])

  const navigate =
useNavigate()

  const [showModal,
  setShowModal] =
  useState(false)

  const [newCompany,
setNewCompany] =
useState({

  id: '',

  name: '',

  password: '',

  adminNumber: ''

})

  useEffect(() => {

    loadCompanies()

  }, [])

  async function loadCompanies() {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      const response =
      await api.get(

        '/companies',

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      setCompanies(
        response.data
      )

    } catch (error) {

      console.log(error)

    }

  }

  //add empresa
  async function createCompany() {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      await api.post(

        '/companies',

        newCompany,

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      alert(
        'Empresa criada!'
      )

      setShowModal(false)

      setNewCompany({

        id: '',

        name: '',

        password: ''

      })

      loadCompanies()

    } catch (error) {

      console.log(error)

      alert(
        'Erro ao criar empresa'
      )

    }

  }


//remover empresa
async function deleteCompany(id) {

  try {

    const token = localStorage.getItem('token')

    await api.delete(`/companies/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })

    alert('Empresa removida!')

    loadCompanies()

  } catch (error) {

    console.log(error)
    alert('Erro ao remover empresa'+error)

  }
}

  //funcao 
  function logout() {

    localStorage.removeItem(
      'token'
    )

    window.location.href = '/'

  }


function whatsapp(){
  window.location.href = 'https://wa.me/+5591991873356'
}

  return (

    <div className='dashboard'>

      <aside className='sidebar'>

        <div>

          <div className='sidebar-top'>

            <div className='sidebar-logo'>
              Y
            </div>

            <h1>
              YHWH
            </h1>

          </div>

          <nav className='menu'>

            <button className='logout'
          onClick={''}>
              📊 Dashboard
            </button>

            <button>
              🏢 Empresas
            </button>

            <button>
              📦 Pedidos
            </button>

            <button>
              📅 Agendamentos
            </button>

            <button onClick={whatsapp}>
              ✨ WhatsApp
            </button>


          </nav>

        </div>

        <button
          className='logout'
          onClick={logout}
        >
          Sair
        </button>

      </aside>

      <main className='content'>

        <div className='topbar'>

          <h1>
            Dashboard
          </h1>

          <p>
            Bem-vindo 🚀
          </p>

        </div>

        <div className='cards'>

          <div className='card'>

            <span>
              Empresas
            </span>

            <h2>
              {companies.length}
            </h2>

          </div>

        </div>

        <div className='companies-box'>

          <div className='companies-header'>

            <h2>
              Empresas
            </h2>

            <button
              onClick={() =>
                setShowModal(true)
              }
            >
              + Nova empresa
            </button>

          </div>

          {

            companies.map(

              company => (

                <div
  className='company-item'
  key={company.id}
  onClick={() => {

    localStorage.setItem(
  'selectedCompany',
  company.id
)

    navigate(
      `/company/${company.id}`
    )

  }}
  style={{
    cursor: 'pointer'
  }}
>

                  <div>

                    <h3>
                      {company.id}
                    </h3>

                    <p>
                      Empresa ativa
                    </p>

                  </div>

                  <span>

  {

    company.status ===
    'online'

    ? '🟢 Online'

    : company.status ===
    'pending'

    ? '🟡 QR Pendente'

    : '🔴 Offline'

  }

</span>

 {/* BOTÃO DE REMOVER */}
  <button
    onClick={(e) => {
      e.stopPropagation() // impede abrir a página da empresa
      deleteCompany(company.id)
    }}
    style={{
      marginLeft: '10px',
      background: 'red',
      color: 'white',
      border: 'none',
      padding: '5px 10px',
      cursor: 'pointer'
    }}
  >
    Remover
  </button>

                </div>

              )

            )

          }

        </div>

        {

          showModal && (

            <div className='modal'>

              <div className='modal-content'>

                <h2>
                  Nova empresa
                </h2>

                

                <input
                  type='text'
                  placeholder='ID'
                  value={newCompany.id}
                  onChange={
                    e =>
                    setNewCompany({

                      ...newCompany,

                      id: e.target.value

                    })
                  }
                />

                <input
                  type='text'
                  placeholder='Nome'
                  value={newCompany.name}
                  onChange={
                    e =>
                    setNewCompany({

                      ...newCompany,

                      name: e.target.value

                    })
                  }
                />

                <input
                  type='password'
                  placeholder='Senha'
                  value={newCompany.password}
                  onChange={
                    e =>
                    setNewCompany({

                      ...newCompany,

                      password: e.target.value

                    })
                  }
                />

                <input
                  type='text'
                  placeholder='Numero Adimin'
                  value={newCompany.adminNumber}
                  onChange={
                    e =>
                    setNewCompany({

                      ...newCompany,

                      adminNumber: e.target.value

                    })
                  }
                />

                <button
                  onClick={createCompany}
                >
                  Criar empresa
                </button>

                <button className='close-modal' onClick={() => setShowModal(false)} >
                  Cancelar
                  </button>

              </div>

            </div>

          )

        }

      </main>

    </div>

  )

}