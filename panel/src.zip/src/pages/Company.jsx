import {
  useNavigate
} from 'react-router-dom'

import {
  useEffect,
  useState
} from 'react'

import api from '../services/api'

import '../App.css'

export default function Company() {

  const companyId =
  localStorage.getItem(
    'selectedCompany'
  )

  const [company,
  setCompany] =
  useState(null)

  const [qr,
  setQr] =
  useState(null)

  const navigate =
useNavigate()

  const allModules = [

    'assistant',

    'checkout',

    'scheduling',

    'catalog'

  ]

  useEffect(() => {

    loadCompany()

    loadQr()

  }, [])

  async function loadCompany() {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      const response =
      await api.get(

        `/companies/${companyId}`,

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      setCompany(
        response.data
      )

    } catch (error) {

      console.log(error)

    }

  }

  async function loadQr() {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      const response =
      await api.get(

        `/companies/${companyId}/qr`,

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      setQr(
        response.data
      )

    } catch (error) {

      console.log(error)

    }

  }

  async function toggleModule(
    moduleName
  ) {

    try {

      const token =
      localStorage.getItem(
        'token'
      )

      let modules =
      company.modules || []

      if (
        modules.includes(
          moduleName
        )
      ) {

        modules =
        modules.filter(
          item =>
          item !== moduleName
        )

      } else {

        modules.push(
          moduleName
        )

      }

      await api.put(

        `/companies/${companyId}/modules`,

        {

          modules

        },

        {

          headers: {

            Authorization:
            `Bearer ${token}`

          }

        }

      )

      loadCompany()

    } catch (error) {

      console.log(error)

    }

  }

  if (!company) {

    return (
      <h1>
        Carregando...
      </h1>
    )

  }

  return (

    <div className='dashboard'>

      <aside className='sidebar'>

        <div>

          <div className='sidebar-top'>

            <div className='sidebar-logo'>
              S
            </div>

            <h1>
              {company.name}
            </h1>

          </div>

        </div>

      </aside>

      <main className='content'>

        <div className='topbar'>

  <button

    onClick={() =>
      navigate('/dashboard')
    }

    style={{

      marginBottom: 20,

      background: '#111827',

      color: 'white',

      border: 'none',

      padding: '12px 20px',

      borderRadius: 12,

      cursor: 'pointer'

    }}

  >

    ← Voltar

  </button>

          <h1>
            {company.name}
          </h1>

          <p>
            Painel da empresa 🚀
          </p>

        </div>

        {/* QR CODE */}

        <div className='companies-box'>

          <h2>
            WhatsApp
          </h2>

          {

            qr?.connected

            ? (

              <h1>
                ✅ CONECTADO
              </h1>

            )

            : qr?.qr ? (

              <img
                src={qr.qr}
                width='300'
              />

            )

            : (

              <p>
                Gerando QR Code...
              </p>

            )

          }

        </div>

        {/* MODULOS */}

        <div
          className='companies-box'
          style={{
            marginTop: 20
          }}
        >

          <h2>
            Módulos
          </h2>

          {

            allModules.map(

              module => (

                <div
                  className='company-item'
                  key={module}
                >

                  <div>

                    <h3>
                      {module}
                    </h3>

                    <p>
                      Módulo do sistema
                    </p>

                  </div>

                  <button

                    onClick={() =>
                      toggleModule(
                        module
                      )
                    }

                    style={{

                      background:
                      company.modules.includes(
                        module
                      )
                      ? '#ef4444'
                      : '#16a34a',

                      color: 'white',

                      border: 'none',

                      padding:
                      '10px 20px',

                      borderRadius: 12,

                      cursor: 'pointer'

                    }}

                  >

                    {

                      company.modules.includes(
                        module
                      )

                      ? 'Remover'

                      : 'Adicionar'

                    }

                  </button>

                </div>

              )

            )

          }

        </div>

      </main>

    </div>

  )

}