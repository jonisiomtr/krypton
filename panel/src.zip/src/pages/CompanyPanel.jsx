import { useState, useEffect } from 'react'
import api from '../services/api'
import '../App.css'

import Modules from '../components/company/Modules'


// PAGINAS
import Dashboard from './panel/Dashboard'
import Orders from './panel/Orders'
import Appointments from './panel/Appointments'
import Products from './panel/Products'
import Services from './panel/Services'
import Settings from './panel/Settings'
import Support from './panel/Support'

export default function CompanyPanel() {

  const companyId =
  localStorage.getItem(
    'companyId'
  )

  const [page, setPage] =
  useState('dashboard')

  const [pendingOrders, setPendingOrders] =
useState(0)

useEffect(() => {

  loadPendingOrders()

  const interval = setInterval(() => {

    loadPendingOrders()

  }, 5000)

  return () =>
    clearInterval(interval)

}, [])

async function loadPendingOrders() {

  try {

    const token =
    localStorage.getItem(
      'token'
    )

    const response =
    await api.get(

      `/pedidos/listar/orders/${companyId}`,

      {

        headers: {

          Authorization:
          `Bearer ${token}`

        }

      }

    )

    const pending =
    response.data.orders.filter(

      order =>
        order.status ===
        'pending'

    )

    setPendingOrders(
      pending.length
    )

  } catch (err) {

    console.log(err)

  }

}

  function logout() {

    localStorage.removeItem(
      'token'
    )

    localStorage.removeItem(
      'companyId'
    )

    window.location.href = '/'

  }

  return (

    <div className='dashboard'>

      <aside className='sidebar'>

        <div className='sidebar-header'>

          <img

            src={

              localStorage.getItem(
                'companyLogo'
              ) ||

              'https://placehold.co/100x100'

            }

            alt='logo'

            className='sidebar-logo'

          />

          <h1 className='sidebar-company'>

            {

              localStorage.getItem(
                'companyDisplayName'
              ) ||

              'Painel da Empresa'

            }

          </h1>

        </div>

        <nav className='sidebar-menu'>

          <button
            className={`sidebar-item ${
              page === 'dashboard'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('dashboard')
            }
          >

            <span className='sidebar-icon'>
              📊
            </span>

            <span className='sidebar-text'>
              Visão Geral
            </span>

          </button>

          <button
  className={`sidebar-item ${
    page === 'orders'
    ? 'active'
    : ''
  }`}
  onClick={() =>
    setPage('orders')
  }
>

  <span className='sidebar-icon'>
    🛒
  </span>

  <span className='sidebar-text'>
    Pedidos
  </span>

  {

    pendingOrders > 0 && (

      <div className='sidebar-notify'>

        {pendingOrders}

      </div>

    )

  }

</button>

          <button
            className={`sidebar-item ${
              page === 'appointments'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('appointments')
            }
          >

            <span className='sidebar-icon'>
              📅
            </span>

            <span className='sidebar-text'>
              Agendamentos
            </span>

          </button>

          <button
            className={`sidebar-item ${
              page === 'products'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('products')
            }
          >

            <span className='sidebar-icon'>
              📦
            </span>

            <span className='sidebar-text'>
              Produtos
            </span>

          </button>

          <button
            className={`sidebar-item ${
              page === 'services'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('services')
            }
          >

            <span className='sidebar-icon'>
              🧰
            </span>

            <span className='sidebar-text'>
              Serviços
            </span>

          </button>

          <button
            className={`sidebar-item ${
              page === 'modules'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('modules')
            }
          >

            <span className='sidebar-icon'>
              🧠
            </span>

            <span className='sidebar-text'>
              Módulos
            </span>

          </button>

          <button
            className={`sidebar-item ${
              page === 'settings'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('settings')
            }
          >

            <span className='sidebar-icon'>
              ⚙️
            </span>

            <span className='sidebar-text'>
              Configurações
            </span>

          </button>

          <button
            className={`sidebar-item ${
              page === 'support'
              ? 'active'
              : ''
            }`}
            onClick={() =>
              setPage('support')
            }
          >

            <span className='sidebar-icon'>
              💬
            </span>

            <span className='sidebar-text'>
              Suporte
            </span>

          </button>

        </nav>

        <button
          className='logout-button'
          onClick={logout}
        >

          🚪 Sair

        </button>

      </aside>

      <main className='content'>

        //inicio da Barra
        <div className='topbar-modern'>

  <div className='topbar-grid'>

    {/* EMPRESA */}
    <div className='topbar-company'>

      <img
        src={
          localStorage.getItem(
            'companyLogo'
          ) || 'https://placehold.co/120'
        }
        alt='logo'
        className='topbar-avatar'
      />

      <div className='topbar-info'>

        <div className='topbar-name-row'>

          <h1>
            {
              localStorage.getItem(
                'companyDisplayName'
              )
            }
          </h1>

          <span className='verified-badge'>
            ✔
          </span>

        </div>

        <p>
          @{companyId}
        </p>

        <div className='topbar-status'>

          <div className='status-dot'></div>

          Empresa online

        </div>

      </div>

    </div>

    {/* CARDS */}
    <div className='topbar-side'>

      <div className='topbar-mini-card'>

        <span>
          Pedidos
        </span>

        <strong>
          {pendingOrders}
        </strong>

      </div>

      <div className='topbar-mini-card blue'>

        <span>
          Robô
        </span>

        <strong>
          On-line
        </strong>

      </div>

      <div className='developer-card'>

        <div className='developer-header'>

          <div className='developer-icon'>
            🐱‍👤
          </div>

          <div>

            <span className='developer-label'>
              Desenvolvedor
            </span>

            <h3>
              João 🍷
            </h3>

          </div>

        </div>

      </div>

    </div>

  </div>

</div>

        //final da barra

        {page === 'dashboard' && (

  <>

    <div className='hero-dashboard'>

      <div className='hero-left'>

        <div className='hero-badge'>
          🚀 PAINEL EMPRESARIAL
        </div>

        <h1 className='hero-title'>

          {localStorage.getItem(
            'companyDisplayName'
          )}

        </h1>

        <p className='hero-description'>

          Gerencie pedidos, produtos,
          atendimentos e automações
          da sua empresa em tempo real.

        </p>

        <div className='hero-status'>

          <div className='status-online'></div>

          Sistema Online

        </div>

      </div>

      <div className='hero-right'>

        <img

          src={
            localStorage.getItem(
              'companyLogo'
            ) ||
            'https://placehold.co/150'
          }

          alt='logo'

          className='hero-logo'

        />

      </div>

    </div>

    <div className='dashboard-stats'>

      <div className='modern-card'>

        <div className='modern-icon blue'>
          🛒
        </div>

        <div>

          <span>
            Pedidos Pendentes
          </span>

          <h2>
            {pendingOrders}
          </h2>

        </div>

      </div>

      <div className='modern-card'>

        <div className='modern-icon green'>
          💰
        </div>

        <div>

          <span>
            Faturamento Hoje
          </span>

          <h2>
            R$ 0
          </h2>

        </div>

      </div>

      <div className='modern-card'>

        <div className='modern-icon purple'>
          📅
        </div>

        <div>

          <span>
            Agendamentos
          </span>

          <h2>
            0
          </h2>

        </div>

      </div>

      <div className='modern-card'>

        <div className='modern-icon orange'>
          ⚡
        </div>

        <div>

          <span>
            Status do Bot
          </span>

          <h2>
            Online
          </h2>

        </div>

      </div>

    </div>

  </>

)}

        {page === 'dashboard' && <Dashboard />}
        {page === 'orders' && <Orders companyId={companyId} />}
        {page === 'appointments' && <Appointments />}
        {page === 'products' && <Products />}
        {page === 'services' && <Services />}
        {page === 'settings' && <Settings />}
        {page === 'support' && ( <Support /> )}
        {page === 'modules' && ( <Modules companyId={companyId}/>)}

        

      </main>

      

      

    </div>

    

    

  )

}

